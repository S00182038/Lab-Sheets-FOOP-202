﻿namespace Lab_Sheet_1
{
    public class PopBand : Band
    {
        private const int ARRAY_SIZE = 5;
        public PopBand()
        {
           Albums = new Album[ARRAY_SIZE];
        }
    }
}

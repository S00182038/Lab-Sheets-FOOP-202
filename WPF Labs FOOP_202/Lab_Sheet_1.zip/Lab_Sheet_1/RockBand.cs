﻿namespace Lab_Sheet_1
{
    public class RockBand : Band
    {
        private const int ARRAY_SIZE = 5;
        public RockBand()
        {
            Albums = new Album[ARRAY_SIZE];
        }
    }
}

﻿namespace Lab_Sheet_1
{
    public class IndieBand : Band
    {      
        private const int ARRAY_SIZE = 5;
        public IndieBand()
        {
            Albums = new Album[ARRAY_SIZE];
        }
    }
}
